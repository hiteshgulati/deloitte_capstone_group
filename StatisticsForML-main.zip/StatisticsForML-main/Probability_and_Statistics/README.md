Day 1
